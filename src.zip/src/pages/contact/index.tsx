import { memo } from "react";
import ContactForm from "./components/ContactForm";

const Contact = () => {
  return (
    <section className="py-16 px-4 md:px-20 bg-gray-50">
      <h2 className="text-3xl font-bold text-center mb-10">Contact Us</h2>

      <div className="grid md:grid-cols-1 gap-10 mb-16">
        <ContactForm />
      </div>
    </section>
  );
};

export default memo(Contact);

import { useTranslation } from "react-i18next";
import { Card, CardContent } from "@/components/ui/card";
import aboutImg from "@/assets/images/homeAbout.jpg";

export const AboutSection = () => {
  const { t } = useTranslation();

  return (
    <section className="py-16 bg-gray-50">
      <div className=" px-4 grid md:grid-cols-2 gap-10 items-center">
        <div className="relative group">
          <img
            src={aboutImg}
            alt="About us"
            className="rounded-2xl shadow-lg w-full h-auto"
          />
        </div>

        <Card className=" border-none shadow-none bg-transparent">
          <CardContent className="p-0">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              {t("home.about.title")}
            </h2>
            <p className="text-gray-600 leading-relaxed mb-6">
              {t("home.about.description")}
            </p>
            <p className="text-gray-600 leading-relaxed">
              {t("home.about.more")}
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

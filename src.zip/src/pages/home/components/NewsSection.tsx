import { memo } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

export const NewsSection = memo(() => {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const newsItems = t("home.news.items", { returnObjects: true }) as {
    title: string;
    description: string;
  }[];

  return (
    <section className="py-16">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold">{t("home.news.title")}</h2>
        <Button onClick={() => navigate("/news")}>{t("home.news.all")}</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {newsItems.map((item, idx) => (
          <div
            key={idx}
            onClick={() => navigate(`/newsDetails/${idx + 1}`)}
            className="cursor-pointer"
          >
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent>
                <CardTitle>{item.title}</CardTitle>
                <p>{item.description}</p>
              </CardContent>
            </Card>
          </div>
        ))}
      </div>
    </section>
  );
});

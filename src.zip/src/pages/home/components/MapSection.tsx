import { memo } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { useTranslation } from "react-i18next";

export const MapSection = memo(() => {
  const latitude = 41.614906;
  const longitude = 70.047144;
  const zoom = 16;
  const { t } = useTranslation();

  const mapSrc = `https://yandex.com/map-widget/v1/?ll=${longitude}%2C${latitude}&z=${zoom}&pt=${longitude},${latitude},pm2rdm`;

  return (
    <section className="py-16 bg-gray-50">
      <div className="px-4">
        <Card className="overflow-hidden shadow-md border-none">
          <CardHeader>
            <CardTitle className="text-2xl font-semibold text-gray-800">
              {t("home.map.title", "Bizning manzil")}
            </CardTitle>
          </CardHeader>
          <CardContent className="relative w-full h-[400px] rounded-xl overflow-hidden">
            <iframe
              title="Renessans joylashuvi"
              src={mapSrc}
              width="100%"
              height="100%"
              loading="lazy"
              allowFullScreen
              className="border-0"
            ></iframe>
          </CardContent>
        </Card>
      </div>
    </section>
  );
});

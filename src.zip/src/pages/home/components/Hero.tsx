import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";

export const Hero = () => {
  const slides = [
    {
      title: "Welcome to Renaissance Camp",
      description: "Where gifted children grow and thrive",
      image: "/images/hero1.jpg",
    },
    {
      title: "Learn & Inspire",
      description: "Technology, Art, Science, and More",
      image: "/images/hero2.jpg",
    },
    {
      title: "Build Your Future",
      description: "Develop skills, make friends, create memories",
      image: "/images/hero3.jpg",
    },
  ];

  return (
    <section className="w-full h-[90vh] relative">
      <Swiper
        modules={[Pagination, Autoplay]}
        pagination={{ clickable: true }}
        autoplay={{ delay: 5000 }}
        loop
        className="h-full"
      >
        {slides.map((slide, idx) => (
          <SwiperSlide key={idx}>
            <div
              className="w-full h-full flex flex-col justify-center items-center text-center bg-cover bg-center"
              style={{
                backgroundImage: `linear-gradient(135deg, rgba(99, 102, 241, 0.6), rgba(167, 139, 250, 0.6)), url(${slide.image})`,
              }}
            >
              <h1 className="text-5xl md:text-7xl font-extrabold text-white drop-shadow-lg text-pretty">
                {slide.title}
              </h1>
              <p className="mt-4 text-xl md:text-2xl text-white drop-shadow-md max-w-2xl px-4">
                {slide.description}
              </p>
              <button className="mt-8 px-8 py-3 bg-indigo-600 text-white rounded-full font-semibold hover:bg-indigo-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                Learn More
              </button>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </section>
  );
};

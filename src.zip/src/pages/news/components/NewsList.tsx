import { memo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardTitle } from "@/components/ui/card";
import newsData from "@/news.json";
import Pagination from "rc-pagination";
import "rc-pagination/assets/index.css"; 

export const NewsList = memo(() => {
  const navigate = useNavigate();
  const newsItems = newsData.en.items;

  const itemsPerPage = 2;
  const [currentPage, setCurrentPage] = useState(1);

  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = newsItems.slice(startIndex, endIndex);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {currentItems.map((item) => (
          <Card
            key={item.id}
            className="hover:shadow-lg transition-shadow cursor-pointer py-0"
            onClick={() => navigate(`/newsDetails/${item.id}`)}
          >
            <img
              src={item.img}
              alt={item.title}
              className="w-full object-cover rounded-t-lg"
            />
            <CardContent>
              <CardTitle>{item.title}</CardTitle>
              <p>{item.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-center mt-6">
        <Pagination
          current={currentPage}
          total={newsItems.length}
          pageSize={itemsPerPage}
          onChange={handlePageChange}
          showTitle={false}
          showLessItems
          className="rc-pagination"
        />
      </div>
    </div>
  );
});

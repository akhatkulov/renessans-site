import { memo } from "react";
import PageTitle from "@/components/common/PageTitle";
import { useTranslation } from "react-i18next";
import { NewsList } from "./components/NewsList";

const AllNewsPage = () => {
  const { t } = useTranslation();

  return (
    <PageTitle titleKey="home.news.title">
      <div className="py-16 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-10">{t("home.news.title")}</h2>
        <NewsList />
      </div>
    </PageTitle>
  );
};

export default memo(AllNewsPage);

import { memo } from "react";
import PageTitle from "@/components/common/PageTitle";
import AboutUsContent from "./components/AboutUsContent";
import AboutUsImage from "./components/AboutUsImage";

const AboutUs = () => {
  return (
    <PageTitle titleKey="header.navbar.aboutUs">
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
          <AboutUsImage />
          <AboutUsContent />
        </div>
      </section>
    </PageTitle>
  );
};

export default memo(AboutUs);

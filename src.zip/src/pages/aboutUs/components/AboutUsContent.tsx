import { memo } from "react";
import { useTranslation } from "react-i18next";

const AboutUsContent = () => {
  const { t } = useTranslation();

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-gray-800">
        {t("aboutUs.content.title")}
      </h2>

      <p className="text-gray-600">{t("aboutUs.content.description")}</p>
      <p className="text-gray-600">{t("aboutUs.content.more")}</p>

      <ul className="list-disc list-inside space-y-2 text-gray-600">
        <li>{t("aboutUs.content.physicalEducation")}</li>
        <li>{t("aboutUs.content.intellectualDevelopment")}</li>
        <li>{t("aboutUs.content.youthStartups")}</li>
        <li>{t("aboutUs.content.internationalCompetitions")}</li>
        <li>{t("aboutUs.content.disabilitySupport")}</li>
        <li>{t("aboutUs.content.digitalMechanisms")}</li>
      </ul>
    </div>
  );
};

export default memo(AboutUsContent);

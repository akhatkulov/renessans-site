import { memo } from "react";
import newsData from "@/news.json";

interface NewsContentProps {
  id: string;
}

export const NewsContent = memo(({ id }: NewsContentProps) => {
  // Faqat English ishlatamiz
  const newsItem = newsData.en.items.find((n) => n.id === id);

  if (!newsItem) return <p>News not found</p>;

  return (
    <div className="py-16 max-w-4xl mx-auto">
      <img
        src={newsItem.img}
        alt={newsItem.title}
        className="w-full h-64 object-cover rounded-lg mb-6"
      />
      <h2 className="text-3xl font-bold mb-4">{newsItem.title}</h2>
      <p className="mb-6">{newsItem.description}</p>
      <div>{newsItem.content}</div>
    </div>
  );
});

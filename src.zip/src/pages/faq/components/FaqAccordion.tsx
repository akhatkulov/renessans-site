import { memo } from "react";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";

interface AccordionItemType {
  title: string;
  content: string;
}

interface Props {
  items: AccordionItemType[];
}

const FaqAccordion = ({ items }: Props) => {
  return (
    <Accordion type="single" collapsible className="space-y-2">
      {items.map((item, idx) => (
        <AccordionItem key={idx} value={`item-${idx}`}>
          <AccordionTrigger className="bg-gray-100 p-4 rounded-md hover:bg-gray-200">
            {item.title}
          </AccordionTrigger>
          <AccordionContent className="p-4 text-gray-600 bg-gray-50 rounded-md">
            {item.content}
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
};

export default memo(FaqAccordion);

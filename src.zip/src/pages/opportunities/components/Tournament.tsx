import { memo } from "react";
import { useTranslation } from "react-i18next";
import tournamentImage from "@/assets/images/tournament.jpg";

const Tournament = () => {
  const { t } = useTranslation();

  return (
    <div className="grid md:grid-cols-2 gap-8 items-center my-12">
      <div className="order-2 md:order-1">
        <h3 className="text-2xl font-bold text-gray-800 mb-4">
          {t("opportunities.tournament.title")}
        </h3>
        <p className="text-gray-600">
          {t("opportunities.tournament.description")}
        </p>
      </div>
      <div className="order-1 md:order-2 rounded-lg overflow-hidden shadow-lg">
        <img
          src={tournamentImage}
          alt={t("opportunities.tournament.title")}
          className="w-full h-auto object-cover"
        />
      </div>
    </div>
  );
};

export default memo(Tournament);

import { memo } from "react";
import { useTranslation } from "react-i18next";
import techImage from "@/assets/images/techPrograms.jpg";

const TechPrograms = () => {
  const { t } = useTranslation();

  return (
    <div className="grid md:grid-cols-2 gap-8 items-center my-12">
      <div>
        <h3 className="text-2xl font-bold text-gray-800 mb-4">
          {t("opportunities.techPrograms.title")}
        </h3>
        <p className="text-gray-600">
          {t("opportunities.techPrograms.description")}
        </p>
      </div>
      <div className="rounded-lg overflow-hidden shadow-lg">
        <img
          src={techImage}
          alt={t("opportunities.techPrograms.title")}
          className="w-full h-auto object-cover"
        />
      </div>
    </div>
  );
};

export default memo(TechPrograms);

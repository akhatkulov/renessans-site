import { Navbar } from "./components/navbar";
import { LanguageSelector } from "./components/LanguageSelector";
import logo from "@/assets/icons/logo.png";
import { Link } from "react-router-dom";

export const Header = () => {
  return (
    <header className="w-full bg-white shadow-md sticky top-0 z-50">
      <div className="container flex flex-col md:flex-row items-center justify-between py-4 gap-4 md:gap-0">
        <Link to={"/"} className="text-2xl font-bold text-blue-600">
          <img src={logo} alt="" width={120} />
        </Link>

        <Navbar />

        <div className="flex items-center gap-4">
          <LanguageSelector />
        </div>
      </div>
    </header>
  );
};

import { memo } from "react";
import FooterLogo from "./components/FooterLogo";
import FooterLinks from "./components/FooterLinks";
import FooterContact from "./components/FooterContact";
import FooterBottom from "./components/FooterBottom";

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 pt-10">
      <div className="container mx-auto px-4 grid md:grid-cols-4 gap-10">
        <div className="md:col-span-1">
          <FooterLogo />
        </div>

        <div className="md:col-span-1">
          <FooterLinks />
        </div>

        <div className="md:col-span-2">
          <FooterContact />
        </div>
      </div>

      <FooterBottom />
    </footer>
  );
};

export default memo(Footer);

import { memo } from "react";
import { useTranslation } from "react-i18next";

const FooterBottom = () => {
  const { t } = useTranslation();

  return (
    <div className="border-t border-gray-700 mt-10 py-4 text-center text-gray-500 text-sm">
      © {new Date().getFullYear()} {t("footer.privacy.title")}
    </div>
  );
};

export default memo(FooterBottom);

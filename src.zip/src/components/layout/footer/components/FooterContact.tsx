import { memo } from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import {
  Phone,
  Mail,
  MapPin,
  Instagram,
  Facebook,
  Youtube,
  Send,
} from "lucide-react";

const FooterContact = () => {
  const { t } = useTranslation();

  return (
    <div>
      <h3 className="text-white font-semibold text-lg mb-3">
        {t("footer.contact.title")}
      </h3>

      <ul className="space-y-2 text-gray-400 text-sm mb-5">
        <li className="flex items-start gap-2">
          <MapPin className="w-4 h-4 text-blue-500 mt-0.5" />
          <span>{t("footer.contact.address")}</span>
        </li>

        <li className="flex items-center gap-2">
          <Phone className="w-4 h-4 text-blue-500" />
          <Link
            to="tel:+998559005490"
            target="_blank"
            className="hover:text-white transition-colors"
          >
            +998 55 900-54-90
          </Link>
        </li>

        <li className="flex items-center gap-2">
          <Mail className="w-4 h-4 text-blue-500" />
          <Link
            to="mailto:support@life-style.uz"
            target="_blank"
            className="hover:text-white transition-colors"
          >
            support@life-style.uz
          </Link>
        </li>
      </ul>

      <div className="flex items-center gap-4">
        <Link
          to="https://t.me/renessans_oromgoh"
          target="_blank"
          rel="noreferrer"
          className="hover:text-blue-400 transition-colors"
        >
          <Send className="w-5 h-5" />
        </Link>
        <Link
          to="https://www.instagram.com/renessans.oromgoh/?igsh=MTI2Zzg0NTZwMG9veg%3D%3D#"
          target="_blank"
          rel="noreferrer"
          className="hover:text-pink-500 transition-colors"
        >
          <Instagram className="w-5 h-5" />
        </Link>
        <Link
          to="https://www.facebook.com/people/Renessansoromgoh/61562837830987/?sk=followers"
          target="_blank"
          rel="noreferrer"
          className="hover:text-blue-600 transition-colors"
        >
          <Facebook className="w-5 h-5" />
        </Link>
        <Link
          to="https://www.youtube.com/@renessans.oromgoh-m8u"
          target="_blank"
          rel="noreferrer"
          className="hover:text-red-500 transition-colors"
        >
          <Youtube className="w-5 h-5" />
        </Link>
      </div>
    </div>
  );
};

export default memo(FooterContact);
